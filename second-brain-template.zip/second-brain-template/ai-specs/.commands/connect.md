---
title: "connect command"
created: 2026-06-04
updated: 2026-06-04
status: active
type: agent
area: system
tags: [command, system, connect, knowledge-graph, linking]
related: ["[[connector]]", "[[gap-detector]]", "[[cross-domain]]"]
confidence: high
---

## Trigger

`/connect`
`/connect [note-path]`
`/connect --orphans`
`/connect --auto`
`/connect --report`

---

## Inputs

| Input | Required | Description |
| ----- | -------- | ----------- |
| `note-path` | Optional | Path to a specific note to audit. If omitted, full vault scan |
| `--orphans` | Flag | Only find notes with zero links in or out |
| `--auto` | Flag | Apply all proposed links without per-link confirmation |
| `--report` | Flag | Show graph state without making changes |

---

## Steps

**If `--report`:**
1. Read `vault-config.json` for the vault path
2. Scan all notes, count incoming and outgoing links per note
3. Calculate: total notes, average links per note, orphan count, most-connected notes, areas with lowest connectivity
4. Output the report — no changes made

**If `--orphans`:**
1. Read `vault-config.json`
2. Find all notes with zero incoming links AND zero outgoing links
3. For each orphan: check if conceptual overlap exists with any other note
4. Propose: connect to [specific note] because [reason], OR archive if no connection makes sense
5. If `--auto` also set: apply connections; otherwise confirm per note

**Standard run (with or without note-path):**
1. Read `vault-config.json` for the vault path
2. Determine scope: specific note (if path given) or all notes with fewer than 3 outgoing links
3. For each note in scope:
   a. Scan `20-knowledge/` for notes with conceptual overlap (shared tags, shared key terms, same area)
   b. Rank candidates by connection quality: direct concept overlap > shared context > loose thematic similarity
   c. Draft proposed links with explicit reasons: "[[note-A]] → [[note-B]] because [specific reason]"
4. Present all proposed links to the user grouped by source note
5. If `--auto`: apply immediately; otherwise wait for per-link confirmation (or "approve all" / "reject all")
6. For confirmed links:
   a. Add `[[target-note]]` inline in the source note body at a relevant point
   b. Add `[[source-note]]` in the target note body
   c. Update `related` frontmatter in both notes
7. Check each confirmed connection: does the relationship warrant a `connection note`?
   - If yes (cross-domain, non-obvious, requires explanation): spawn **cross-domain**
8. Report what was linked

---

## Output format

```
Connection audit complete.

Proposed: [N] links
Confirmed: [N] links
Applied: [N] bidirectional link pairs

Notes updated:
- [[note-a]] ↔ [[note-b]]: [reason]
- [[note-c]] ↔ [[note-d]]: [reason]

Connection notes created: [N]
Remaining orphans: [N]
```

---

## Gate conditions

- Default: confirm each proposed link before applying
- With `--auto`: no per-link confirmation; summary shown after
- Cross-domain connections are always flagged for human review before a connection note is created

---

## Error states

| Situation | Response |
| --------- | -------- |
| Note-path does not exist | Report error, list notes in the same area as suggestions |
| No connections found for a note | Report: "No strong connection candidates found for [[note]]. It may need more content first." |
| Connection would create a circular reference | Flag it; do not automatically apply |
