---
title: "build-agent command"
created: 2026-06-04
updated: 2026-06-04
status: active
type: agent
area: system
tags: [command, system, build-agent, meta, agent-creation]
related: ["[[agent-builder]]", "[[researcher]]", "[[connector]]"]
confidence: high
---

## Trigger

`/build-agent [topic]`
`/build-agent --quick [topic]`
`/build-agent --subagent [topic] for [parent-agent]`
`/build-agent --extend [existing-agent] with [capability]`
`/build-agent --audit [agent-path]`

---

## Inputs

| Input | Required | Description |
| ----- | -------- | ----------- |
| `topic` | Required | The domain or subject the new agent will specialise in |
| `--quick` | Flag | Skip deep domain research; build from existing knowledge |
| `--subagent` | Flag | Build a sub-agent scoped to a parent agent |
| `--extend` | Flag | Add capability to an existing agent instead of creating new |
| `--audit` | Flag | Review an existing agent spec |

If no topic provided: ask "What domain or task should the new agent cover?"

---

## Steps

1. Read `vault-config.json` for the vault path
2. Read `00-me.md` to understand the user's level in the target domain

**Overlap check:**
3. List all existing agents in `40-system/agents/`
4. Check for scope overlap with the requested topic
5. If significant overlap found: propose extending the existing agent instead
6. Wait for the user to confirm: new agent vs. extend existing

**Domain research (full build only, skipped for `--quick`):**
7. Spawn **researcher** with the brief:
   - "Map the domain [topic]: core sub-areas, key concepts a practitioner needs, most common mistakes and misconceptions, highest-signal sources"
8. Wait for researcher results before proceeding

**Agent spec generation:**
9. Draft the full agent specification following `vault-templates/agent.md`:
   - Role definition (specific and constraining)
   - What the agent knows deeply (5-8 named competencies)
   - Pre-action checklist
   - Command table
   - Sub-agents it can spawn
   - Note structure for this domain
   - Quality bar with explicit include/exclude
   - Best sources with reasoning
   - Related agents

**Gate:**
10. Show the complete draft to the user
11. Wait for explicit approval or revision requests
12. Apply revisions and show again if substantive changes are requested

**Post-approval:**
13. Write to `40-system/agents/[domain]-agent.md` in the vault
14. Generate knowledge index at `20-knowledge/[area]/[domain]/[domain]-index.md`
15. Spawn **connector** to link the new agent note to related knowledge notes

---

## Output format

```
Agent built: [domain]-agent
Written to: 40-system/agents/domain-agent.md
Index created: 20-knowledge/[area]/[domain]/domain-index.md
Linked to: [[knowledge-note-1]], [[knowledge-note-2]]
```

---

## Gate conditions

- **Hard gate at step 10**: always show the complete draft before writing anything to the vault
- **Overlap gate at step 5**: always check for existing agents first; do not silently create a duplicate
- Sub-agents have a lower gate: show a summary, not the full spec, before writing

---

## Error states

| Situation | Response |
| --------- | -------- |
| No topic provided | Ask "What domain or task should the agent cover?" |
| Significant overlap with existing agent | Show the existing agent, ask: extend vs. new? |
| Domain research returns low-quality sources | Flag it: "I couldn't find high-signal sources for this domain. The agent spec will have lower confidence." |
| User declines at gate | Abort write; offer to revise the spec or drop the task |
