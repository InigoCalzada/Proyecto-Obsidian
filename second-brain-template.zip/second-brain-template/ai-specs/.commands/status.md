---
title: "status command"
created: 2026-06-04
updated: 2026-06-04
status: active
type: agent
area: system
tags: [command, system, status, health-check, proactive]
related: ["[[gap-detector]]", "[[connector]]", "[[weekly-digest]]"]
confidence: high
---

## Trigger

`/status`

No arguments. This command runs automatically at session start as part of the proactive intelligence report. It can also be run on demand.

---

## Inputs

None.

---

## Steps

1. Read `vault-config.json` for the vault path
2. Read `00-me.md`

**Stale detection:**
3. Scan all notes with `status: active`
4. Filter for notes with `updated` older than 180 days in fast-moving areas:
   - Fast-moving areas: AI/ML, security, React/Next.js ecosystem, paid media, Node.js tooling, any framework-specific knowledge
5. List: note name + last updated date + area

**Orphan detection:**
6. Scan all notes in `20-knowledge/`
7. Find notes with zero outgoing `[[links]]` in the body AND not present in any other note's `related` field
8. List: note name + area

**Gap detection (summary):**
9. Cross-reference `10-projects/` technologies against `20-knowledge/` notes
10. Find technologies used in 2+ projects with no knowledge note
11. List: technology + projects that use it

**Cross-domain pattern scan:**
12. Scan `20-knowledge/` for concepts appearing in 3+ different areas
13. Check `20-knowledge/cross-domain/` — does a connection note already exist for it?
14. If not: flag as a candidate for `/synthesise`

**Compile report:**
15. Output the formatted status report

---

## Output format

If issues found:
```
--- Second Brain Status — [YYYY-MM-DD] ---

Stale notes (active, >180 days, fast-moving area):
• [[note-name]] — last updated [date] — area: [area]
  → /research --update [note-path]

Orphan notes (zero links):
• [[note-name]] — area: [area]
  → /connect [note-path]

Knowledge gaps (used in 2+ projects, no knowledge note):
• [technology] — used in: [[proj-1]], [[proj-2]]
  → /research [technology]

Cross-domain patterns detected:
• [concept] appears in [area-1], [area-2], [area-3] — no connection note yet
  → /synthesise --concept [concept]

------------------------------------------
```

If nothing to report:
```
--- Second Brain: all clear ---
```

---

## Gate conditions

No gate. `/status` is read-only — it never writes to the vault (only reads).

---

## Error states

| Situation | Response |
| --------- | -------- |
| `vault-config.json` missing | "vault-config.json not found. Run /vault-setup to initialise the system." |
| Vault path does not exist | "Vault path from vault-config.json does not exist on disk. Has it moved? Run /vault-setup to update the path." |
| `00-me.md` missing | "00-me.md not found. I can't calibrate the status report to your priorities. Let's create it — what areas do you work in?" |
| Vault is empty | Report: "Vault is set up but has no notes yet. Start with /audit [project] or /research [topic]." |
