---
title: "weekly command"
created: 2026-06-04
updated: 2026-06-04
status: active
type: agent
area: system
tags: [command, system, weekly, digest, maintenance]
related: ["[[weekly-digest]]", "[[researcher]]", "[[connector]]"]
confidence: high
---

## Trigger

`/weekly`
`/weekly --areas [area1] [area2]`
`/weekly --since [date]`
`/weekly --promote [digest-note]`

---

## Inputs

| Input | Required | Description |
| ----- | -------- | ----------- |
| (none) | — | Use `00-me.md` defaults |
| `--areas` | Flag | Override defaults with specific areas for this run |
| `--since` | Flag | Custom time window (e.g., `--since 2026-05-21` for two weeks) |
| `--promote` | Flag | Promote items from an existing digest note to permanent knowledge |

---

## Steps

1. Read `vault-config.json` for the vault path
2. Read `00-me.md` — extract default areas of interest and active projects

**Area confirmation (interactive runs):**
3. Ask: "Any areas to add this week beyond your defaults from 00-me.md?" — wait for answer
4. Build the final list of areas to cover

**Research per area:**
5. For each area: spawn **researcher** with brief: "[area] developments in the past 7 days [or since date]"
6. Filter returned findings: discard anything not affecting the user's stack, projects, or learning objectives
7. For each relevant finding: cross-reference against the vault
   - Which existing notes are affected?
   - Does this represent new information that has no vault coverage?

**Digest compilation:**
8. Organise findings by area (not by source or date)
9. For each area: what changed, which notes need updating, what deserves a new note
10. Build "low-signal" list for areas that were checked but had nothing relevant
11. Draft the digest note

**Note generation:**
12. Write digest to `00-inbox/weekly-digest-[YYYY-MM-DD].md`

**`--promote` mode:**
1. Read the specified digest note
2. For each item in "Promote to permanent knowledge": ask the user whether to proceed with `/research` or `/process`
3. Spawn the appropriate command for confirmed items
4. Spawn **connector** after any new notes are created

---

## Output format

```
Weekly digest complete — [YYYY-MM-DD]

Areas covered: [area-1], [area-2], [area-3]

Highlights:
• [Area 1]: [one-line summary of most important development]
• [Area 2]: [one-line summary]

Notes flagged for update: [N]
New research recommended: [N]
Low-signal areas: [area-3], [area-4]

Full digest: 00-inbox/weekly-digest-[date].md
```

---

## Gate conditions

No gate — the digest writes to `00-inbox/` without requiring confirmation. The inbox is the review stage.

The `--promote` variant has a soft gate per item: confirm before spawning research or process.

---

## Error states

| Situation | Response |
| --------- | -------- |
| `00-me.md` has no areas defined | Ask: "I don't have your default areas yet. What areas do you want to cover this week?" |
| All areas are low-signal this week | Report this explicitly — do not pad with noise |
| `--promote` note path not found | Report error, list recent digest notes in `00-inbox/` |
| `--since` date is in the future | Report error |
