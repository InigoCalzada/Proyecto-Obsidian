---
title: "vault-setup command"
created: 2026-06-04
updated: 2026-06-04
status: active
type: agent
area: system
tags: [command, system, vault-setup, initialisation]
related: ["[[auditor]]", "[[gap-detector]]"]
confidence: high
---

## Trigger

`/vault-setup`

No arguments. This command runs once at system initialisation. It can be re-run to repair or extend the structure.

---

## Inputs

None required. The command gathers what it needs interactively.

If `vault-config.json` does not exist: asks for the vault path before proceeding.

---

## Steps

**Pre-flight checks:**
1. Check whether `vault-config.json` exists at the project root
   - If not: ask "What is the absolute path to your Obsidian vault?" — wait for answer, then create `vault-config.json`
   - If yes: read the vault path from it
2. Check whether the vault path actually exists on disk
   - If not: report the error and ask for the correct path
3. List what already exists inside the vault — do not overwrite anything already there

**Gate — show before creating:**
4. Print the full list of directories and files that will be created:
   ```
   Will create:
   [vault_path]/00-inbox/
   [vault_path]/10-projects/
   [vault_path]/20-knowledge/
   [vault_path]/30-resources/
   [vault_path]/40-system/
   [vault_path]/40-system/agents/
   [vault_path]/40-system/commands/
   [vault_path]/40-system/agents/[all 12 agent placeholder files]
   [vault_path]/README.md
   [vault_path]/00-me.md (guided creation — see step 8)
   ```
5. **Wait for explicit user confirmation before creating anything**

**Creation sequence (only after confirmation):**
6. Create all folder structure using `vault-init.sh` or direct file operations
7. Copy all 12 agent files from `ai-specs/.agents/` to `[vault_path]/40-system/agents/`
8. Copy all 13 command files from `ai-specs/.commands/` to `[vault_path]/40-system/commands/`
9. Write `README.md` at vault root with:
   - What the system is
   - Folder structure explanation
   - How to use commands
   - How to use agents
   - Contact: where CLAUDE.md lives
10. Do **not** create `00-me.md` automatically — tell the user to run `/status` for a first session, then build `00-me.md` through conversation

---

## Output format

```
Vault setup complete.

Created:
✓ 00-inbox/
✓ 10-projects/
✓ 20-knowledge/
✓ 30-resources/
✓ 40-system/agents/ (12 agents)
✓ 40-system/commands/ (13 commands)
✓ README.md

Next step: run /status to see the current state of your (empty) vault,
then start a conversation to build 00-me.md.
```

---

## Gate conditions

- **Hard gate at step 5**: never create anything before showing the full list and receiving confirmation
- **No overwrite**: if a folder or file already exists, skip it silently and note in the summary "already existed: X"
- **Path validation**: if the vault path does not exist on disk, stop and report — do not create a vault in the wrong location

---

## Error states

| Situation | Response |
| --------- | -------- |
| `vault-config.json` missing | Ask for vault path, create the file, then continue |
| Vault path does not exist on disk | Report error, ask for correct path |
| User declines at the gate | Abort — do not create partial structure |
| Some folders already exist | Skip existing, create only missing, report both |
