---
title: "process command"
created: 2026-06-04
updated: 2026-06-04
status: active
type: agent
area: system
tags: [command, system, process, content-extraction, resources]
related: ["[[content-processor]]", "[[connector]]", "[[researcher]]"]
confidence: high
---

## Trigger

`/process [url-or-file]`
`/process --video [youtube-url]`
`/process --audio [file-path]`
`/process --pdf [file-path]`
`/process --article [url]`
`/process --batch [list]`

---

## Inputs

| Input | Required | Description |
| ----- | -------- | ----------- |
| `url-or-file` | Required | URL or absolute file path to the content |
| `--video` | Flag | Force YouTube transcript extraction mode |
| `--audio` | Flag | Force audio transcription mode |
| `--pdf` | Flag | Force PDF extraction mode |
| `--article` | Flag | Force web article extraction mode |
| `--batch` | Flag | Process a list — one URL or file per line |

If no input provided: ask "What URL or file should I process?"

---

## Steps

1. Read `vault-config.json` for the vault path
2. Read `00-me.md` to understand what the user likely already knows in this area

**Content type detection:**
3. If no flag given, detect content type from URL or file extension:
   - `youtube.com` or `youtu.be` → video mode
   - `.mp3`, `.m4a`, `.wav`, `.ogg` → audio mode
   - `.pdf` → PDF mode
   - Any other URL → article mode
4. If type is ambiguous: ask

**Duplication check:**
5. Search `30-resources/` for the URL or title — has this source already been processed?
6. If found: show the existing note and ask whether to update it or abort

**Extraction by type:**

*Video (YouTube):*
7. Extract transcript
8. Identify key moments — timestamps where a substantive insight occurs (not intro, not transitions)
9. Distil concepts: what underlying principle or framework is being described?

*Audio:*
7. Transcribe
8. Extract insights with timestamps
9. Distil concepts

*PDF:*
7. Identify document type (academic paper / technical report / book / documentation)
8. Extract: key arguments, data points, frameworks, and conclusions
9. For academic papers: abstract + methods + results + limitations

*Article:*
7. Identify the genuine insight (often 1-3 paragraphs of the whole piece)
8. Discard padding, author bio, SEO scaffolding
9. Extract frameworks or principles if present

**Note generation:**
10. Draft resource note following `vault-templates/resource.md`
11. Identify concepts in the content that map to existing `20-knowledge/` notes → add links
12. Identify concepts that should have a knowledge note but don't → flag as gaps
13. Write to `30-resources/[type]/[title-slug].md`
14. Spawn **connector** to integrate extracted concepts into the network

---

## Output format

```
Processed: [title]
Type: [video/audio/pdf/article]
Written to: 30-resources/[type]/title-slug.md

Key insights: [N]
Concepts linked: [[concept-1]], [[concept-2]]
Gaps flagged: [concept-x] has no knowledge note → /research [concept-x]
```

---

## Gate conditions

- No hard gate — resource notes write directly to `30-resources/`
- The user reviews the note and decides whether to create knowledge notes from the flagged concepts

---

## Error states

| Situation | Response |
| --------- | -------- |
| No input provided | Ask "What URL or file should I process?" |
| URL is inaccessible | Report error, ask for a local copy or alternative |
| File path does not exist | Report error, ask for the correct path |
| Source already processed | Show existing note, ask to update or abort |
| Content is low quality | Flag it: "This source appears to be [SEO filler/marketing content]. Worth processing?" |
