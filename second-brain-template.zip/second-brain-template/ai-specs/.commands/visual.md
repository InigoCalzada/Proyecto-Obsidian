---
title: "visual command"
created: 2026-06-04
updated: 2026-06-04
status: active
type: agent
area: system
tags: [command, system, visual, html, animation, diagrams]
related: ["[[visual-notes]]", "[[learning-map]]", "[[content-processor]]"]
confidence: high
---

## Trigger

`/visual [topic]`
`/visual --movement [exercise]`
`/visual --flow [process]`
`/visual --diagram [system]`
`/visual --update [file-path]`

---

## Inputs

| Input | Required | Description |
| ----- | -------- | ----------- |
| `topic` | Required | Concept, exercise, process, or system to visualise |
| `--movement` | Flag | Force movement sequence animation mode |
| `--flow` | Flag | Force flow diagram mode |
| `--diagram` | Flag | Force system/state diagram mode |
| `--update` | Flag | Update an existing visual file |

If no topic provided: ask "What do you want to visualise?"

---

## Steps

1. Read `vault-config.json` for the vault path

**Need assessment:**
2. Assess whether the concept genuinely requires a visual
   - If markdown text and a simple ASCII or mermaid diagram would communicate it clearly: say so and offer that as an alternative
   - If the concept has movement, phases, spatial relationships, or flow that text cannot convey: proceed

**Visual type detection (if no flag):**
3. Movement with phases (exercises, techniques, body positions) → movement animation
4. Process or decision flow (pipeline, algorithm, workflow) → flow diagram SVG
5. System with states or components (architecture, state machine) → system diagram
6. Spatial or anatomical (body parts, room layouts, data structures) → layered SVG

**Concept draft:**
7. Describe the visual in plain language before writing any code:
   - How many phases/states/nodes?
   - What labels are needed?
   - What is the key moment the visual must convey?

**Gate:**
8. Show the visual concept description to the user
9. Wait for confirmation or adjustments before building

**Build:**
10. Write the HTML file — zero external dependencies, system fonts only
11. Verify file size: if over 50KB, simplify (reduce SVG path detail, shorten animation sequences, strip whitespace)
12. Write to `30-resources/visuals/[topic-slug].html`
13. Write companion markdown note to `20-knowledge/[area]/[topic]/[topic]-visual.md`
    - Must include full text description of every phase, state, and label

**`--update` mode:**
1. Read the existing HTML file
2. Ask: "What should I change? (Add a phase, fix a label, adjust timing, add a state, other)"
3. Make the change
4. Verify file is still under 50KB
5. Write updated file

---

## Output format

```
Visual created: [topic]

HTML file: 30-resources/visuals/topic-slug.html ([size]KB)
Companion note: 20-knowledge/[area]/[topic]/topic-visual.md

To embed in Obsidian: ![[30-resources/visuals/topic-slug.html]]
(Requires the Obsidian HTML plugin)
```

---

## Gate conditions

- **Soft gate at step 8**: always describe the visual concept before building and wait for confirmation
- Hard file size limit: 50KB — never write a file over this limit

---

## Error states

| Situation | Response |
| --------- | -------- |
| No topic provided | Ask "What do you want to visualise?" |
| Text-based explanation would work fine | Recommend markdown + mermaid instead; ask if they still want HTML |
| Generated file exceeds 50KB | Simplify: reduce animation phases, simplify SVG paths, strip whitespace; report final size |
| `--update` file not found | Report error, list existing visual files in `30-resources/visuals/` |
| Concept is too abstract for meaningful visualisation | Report this and suggest `/research [topic]` to build the knowledge note first |
