---
title: "synthesise command"
created: 2026-06-04
updated: 2026-06-04
status: active
type: agent
area: system
tags: [command, system, synthesise, cross-domain, patterns]
related: ["[[cross-domain]]", "[[connector]]", "[[researcher]]"]
confidence: high
---

## Trigger

`/synthesise`
`/synthesise --areas [A] [B]`
`/synthesise --concept [concept]`
`/synthesise --verify [connection-note]`

---

## Inputs

| Input | Required | Description |
| ----- | -------- | ----------- |
| (none) | — | Full vault cross-domain scan |
| `--areas` | Flag | Scope synthesis to two specific areas |
| `--concept` | Flag | Find all manifestations of a specific concept across domains |
| `--verify` | Flag | Stress-test an existing connection note |

---

## Steps

**Full scan:**
1. Read `vault-config.json` for the vault path
2. Read `00-me.md` — which areas does the user actively work in? (Focus on these)
3. Scan all notes in `20-knowledge/`
4. Identify candidates:
   - Concepts appearing in 3+ different areas (by tags or body mentions)
   - Mechanisms described in one area that match mechanisms in another
   - Failure modes that appear in multiple domains
   - Principles stated in one area never applied to another in the vault
5. For each candidate connection: stress-test it
   - Can the structural argument be stated in one paragraph?
   - Can the limits of the analogy be stated explicitly?
   - Does the connection generate actionable insight (changes how you approach at least one domain)?
6. Discard candidates that fail the stress test
7. Draft `connection notes` for survivors

**Gate:**
8. Present each proposed connection with:
   - The pattern name
   - Where it appears (Domain A + Domain B)
   - The structural argument in 2-3 sentences
   - Where the analogy breaks down
9. Wait for user to confirm, reject, or request revision per connection

**Post-approval:**
10. Write confirmed connection notes to `20-knowledge/cross-domain/`
11. Spawn **connector** to update `related` frontmatter in all referenced notes

**`--verify` mode:**
1. Read the specified connection note
2. Re-examine both referenced notes — have they changed?
3. Check whether new knowledge in either domain has strengthened or weakened the analogy
4. Report: still valid / weakened / strengthened / now broken
5. If broken: propose archiving or revising the note

---

## Output format

```
Synthesis complete.

Patterns found: [N]
Confirmed: [N]

Connection notes written:
• [Pattern name] — [[domain-a-note]] ↔ [[domain-b-note]]
  20-knowledge/cross-domain/pattern-name.md

Rejected (failed stress test): [N]
```

---

## Gate conditions

- **Hard gate at step 8**: proposed connections are always shown with full structural argument before writing
- Connection notes are never created automatically — user confirmation required per connection

---

## Error states

| Situation | Response |
| --------- | -------- |
| Vault has fewer than 10 notes | Report: "Not enough notes for meaningful synthesis. Build knowledge in a few areas first." |
| No cross-domain patterns found | Report: "No strong cross-domain patterns detected in current vault state." |
| `--areas` specified but one area has no notes | Report the missing area, offer to proceed with available areas |
| `--verify` note path does not exist | Report error |
