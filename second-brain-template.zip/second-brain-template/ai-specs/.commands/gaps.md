---
title: "gaps command"
created: 2026-06-04
updated: 2026-06-04
status: active
type: agent
area: system
tags: [command, system, gaps, knowledge-gaps, quality]
related: ["[[gap-detector]]", "[[researcher]]", "[[connector]]"]
confidence: high
---

## Trigger

`/gaps`
`/gaps --quick`
`/gaps --area [area]`
`/gaps --stale`
`/gaps --orphans`
`/gaps --critical`

---

## Inputs

| Input | Required | Description |
| ----- | -------- | ----------- |
| `--quick` | Flag | Technology cross-reference only; skip confidence and staleness analysis |
| `--area` | Flag | Scope analysis to a specific area |
| `--stale` | Flag | Only return stale notes |
| `--orphans` | Flag | Only return orphan notes |
| `--critical` | Flag | Only return gaps present in 3+ projects or in active learning objectives |

---

## Steps

1. Read `vault-config.json` for the vault path
2. Read `00-me.md` — note learning objectives and areas of active interest

**Inventory build:**
3. Read all notes in `10-projects/` — extract every technology, concept, and pattern mentioned
4. Scan `20-knowledge/` — build an index of what is documented, keyed by concept and tag

**Gap detection (full run):**
5. **Technology gaps**: cross-reference project technologies against knowledge notes
   - Technologies used in 2+ projects with no knowledge note → high priority
   - Technologies used in 1 project with no note → medium priority
6. **Missing definitions**: scan all note bodies for `[[links]]` to non-existent notes
7. **Confidence gaps**: find areas where all notes are `confidence: low`
8. **Staleness check**: find `status: active` notes with `updated` older than 180 days in fast-moving areas
   (fast-moving: AI/ML, security, React ecosystem, paid media, Node.js tooling)
9. **Orphan check**: find notes with zero incoming and zero outgoing links

**Gap detection (--quick):**
5-9. Only steps 5 (technology cross-reference) and 6 (missing definitions)

**Prioritisation:**
10. Apply priority scoring:
    - Used in 3+ projects AND in learning objectives → critical
    - Used in 2+ active projects → high
    - Referenced but undefined → medium-high
    - Stale active note in fast-moving area → medium
    - Low-confidence area with active usage → medium
    - Orphan note → low

**Report generation:**
11. Write gap report to `00-inbox/gap-report-[YYYY-MM-DD].md`
12. Print summary to the user

---

## Output format

```
Gap analysis complete — [YYYY-MM-DD]

CRITICAL (3+ projects, no note):
• [technology/concept] — used in [[proj-1]], [[proj-2]], [[proj-3]]
  → /research [topic]

HIGH (2+ projects):
• [technology] — used in [[proj-1]], [[proj-2]]
  → /research [topic]

MISSING DEFINITIONS:
• [[concept]] — referenced in [[note-a]], [[note-b]] but never defined
  → create stub in 20-knowledge/[area]/concept.md

STALE NOTES:
• [[note-name]] — last updated [date] — area: [area]
  → /research --update [note-path]

ORPHANS:
• [[note-name]] — /connect [note-path]

Full report: 00-inbox/gap-report-[date].md
```

---

## Gate conditions

No gate — gap analysis reads the vault but never writes to it (only writes a report to `00-inbox/`).

---

## Error states

| Situation | Response |
| --------- | -------- |
| `10-projects/` is empty | Report: "No project notes found. Run /audit [project] to document your first project." |
| `20-knowledge/` is empty | Skip cross-reference, report all project technologies as gaps |
| `--area` specified but no notes in that area | Report: "No notes found in area [area]." |
