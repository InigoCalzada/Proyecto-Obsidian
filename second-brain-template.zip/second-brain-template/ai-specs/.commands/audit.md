---
title: "audit command"
created: 2026-06-04
updated: 2026-06-04
status: active
type: agent
area: system
tags: [command, system, audit, projects]
related: ["[[auditor]]", "[[gap-detector]]", "[[connector]]"]
confidence: high
---

## Trigger

`/audit [path-or-description]`
`/audit --marketing [name]`
`/audit --update [project-name]`

---

## Inputs

| Input | Required | Description |
| ----- | -------- | ----------- |
| `path` | Optional | Absolute or relative path to a code project on disk |
| `description` | Optional | Natural language description of the project (for projects without a local path) |
| `--marketing` | Flag | Switches to marketing project mode |
| `--update` | Flag | Re-audits an existing project note |

If neither a path nor a description is provided: ask "What project are we auditing? Give me a path or a short description."

---

## Steps

1. Read `vault-config.json` for the vault path
2. Read `00-me.md` to calibrate technical depth and vocabulary

**Duplication check:**
3. Search `10-projects/` for notes with a similar project name, similar technology stack, or similar description
4. If a match is found: show the user what exists. Ask: "This looks like it might already be documented as [[project-name]]. Should I enrich that note instead of creating a new one?"
5. Wait for answer before proceeding

**Data gathering (code projects):**
6. If a path was provided: scan the project directory
   - Read the file tree (2 levels deep)
   - Read the dependency manifest (package.json, requirements.txt, Cargo.toml, go.mod, etc.)
   - Identify entry points (main files, index files, CLI entry)
   - Read key config files (Dockerfile, .env.example, CI config)
   - Read the README if present
7. If no path: ask targeted questions to extract the same intelligence — one question at a time

**Data gathering (marketing projects):**
6. Ask for: objective and KPI, channels used, strategy, timeframe, results (numbers), what was never tested
7. Ask for campaign name and approximate dates

**Note generation:**
8. Draft the project note following `vault-templates/project.md`
9. Populate all sections with extracted intelligence (no placeholders)
10. Identify all technologies and concepts that should link to `20-knowledge/` notes

**Gate:**
11. Show the complete draft to the user
12. Wait for approval or revision requests
13. Apply any changes requested

**Post-write:**
14. Write the approved note to `10-projects/[project-name].md`
15. Spawn **connector** to link the new note to relevant `20-knowledge/` notes
16. Spawn **gap-detector** with the list of technologies and concepts extracted — check for missing knowledge notes

---

## Output format

```
Audit complete: [[project-name]]

Written to: 10-projects/project-name.md
Linked to: [[knowledge-note-1]], [[knowledge-note-2]]

Gaps detected: [N] technologies used but not documented
→ Run /gaps to see the full list
```

---

## Gate conditions

- **Hard gate at step 11**: the generated note is always shown to the user before writing to the vault
- **Duplication gate at step 4**: always check for existing notes first; never silently create a duplicate

---

## Error states

| Situation | Response |
| --------- | -------- |
| Path provided does not exist on disk | Report error, ask for the correct path or offer to switch to description mode |
| No input provided | Ask "What project are we auditing?" |
| Existing note found | Show it, ask whether to enrich or create new |
| Project is too large to scan completely | Scan top-level structure and key files; ask user to clarify what to focus on |
