---
title: "research command"
created: 2026-06-04
updated: 2026-06-04
status: active
type: agent
area: system
tags: [command, system, research, knowledge-acquisition]
related: ["[[researcher]]", "[[connector]]", "[[gap-detector]]"]
confidence: high
---

## Trigger

`/research [topic]`
`/research --quick [topic]`
`/research --update [note-path]`
`/research --compare [A] vs [B]`

---

## Inputs

| Input | Required | Description |
| ----- | -------- | ----------- |
| `topic` | Required | The topic to research. Can be a concept, technology, question, or subject area |
| `--quick` | Flag | 2-3 sources, single angle, fast lookup |
| `--update` | Flag | Re-research an existing note. Requires note-path |
| `--compare` | Flag | Structured comparison between two things |

If no topic is provided: ask "What should I research?"

---

## Steps

1. Read `vault-config.json` for the vault path
2. Read `00-me.md` — note the user's level in this area; do not re-explain what they already know

**Duplication check:**
3. Search `20-knowledge/` for notes with similar title, tags, or conceptual overlap
4. If a match found: inform the user ("A note on this already exists: [[note-name]]") and propose:
   - Option A: enrich the existing note (default for closely matching topics)
   - Option B: create a new note linked to the existing one (for genuinely different scope)
5. Proceed based on the user's choice

**Research design:**
6. Identify 5-8 distinct search angles for the topic (skipped for `--quick`)
7. Document the angles in the draft note before executing searches

**Research execution:**
8. Execute searches for each angle
9. For each source encountered: assess credibility (primary source? practitioner experience? SEO content?)
10. Discard: opinion without data, content older than 2 years for fast-moving topics, filler designed to rank
11. Track which source supports which claim

**Synthesis:**
12. Identify: what is solid (multi-source agreement), what is debated (source disagreement), what is outdated (shifted consensus)
13. Assign `confidence` per claim, not per note
14. Add `[as of YYYY-MM]` timestamp to claims that will age

**Note generation:**
15. Draft the research note following `vault-templates/knowledge-note.md`
16. Write to `00-inbox/[topic-slug].md` — never directly to `20-knowledge/`
17. Spawn **connector** to identify links to existing notes

---

## Output format

```
Research complete: [topic]

Written to: 00-inbox/topic-slug.md
Confidence breakdown: high ([N] claims), medium ([N]), low ([N])
Linked to: [[note-1]], [[note-2]]
Gaps flagged: [topic-x] has no knowledge note

Review in 00-inbox, then promote to 20-knowledge/[area]/[topic]/ when satisfied.
```

---

## Gate conditions

- No hard gate — research output goes directly to `00-inbox/` without requiring confirmation
- The inbox is the gate: the user decides when the note is ready to promote to permanent knowledge

---

## Error states

| Situation | Response |
| --------- | -------- |
| No topic provided | Ask "What should I research?" |
| Existing note found | Show it, ask enrich vs. new |
| Topic too broad | Suggest 2-3 more focused sub-topics; ask which to start with |
| Fast-moving topic with only old sources found | Flag this explicitly: "Best sources found are from [year] — this area may have shifted. Confidence set to low." |
