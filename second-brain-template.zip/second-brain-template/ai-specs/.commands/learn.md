---
title: "learn command"
created: 2026-06-04
updated: 2026-06-04
status: active
type: agent
area: system
tags: [command, system, learn, learning-map, curriculum]
related: ["[[learning-map]]", "[[researcher]]", "[[gap-detector]]"]
confidence: high
---

## Trigger

`/learn [topic]`
`/learn --from [A] to [B]`
`/learn --update [map-path]`
`/learn --checkpoint [topic]`
`/learn --audit [topic]`

---

## Inputs

| Input | Required | Description |
| ----- | -------- | ----------- |
| `topic` | Required | Topic to build a learning map for |
| `--from ... to` | Flag | Explicit start and end points |
| `--update` | Flag | Update an existing learning map |
| `--checkpoint` | Flag | Design a checkpoint for a specific phase |
| `--audit` | Flag | Audit an existing map for source quality and sequence validity |

If no topic provided: ask "What do you want to learn?"

---

## Steps

1. Read `vault-config.json` for the vault path
2. Read `00-me.md` — note the user's stated and implied level in the target area and related areas

**Prerequisite audit:**
3. Scan `20-knowledge/[area]/` for existing notes on the topic or related concepts
4. Spawn **gap-detector** scoped to prerequisites: "What foundational knowledge is required before [topic]? Does the user have it?"
5. If prerequisites are missing: flag them — the user must decide whether to fill them first or proceed anyway

**Landscape research:**
6. Spawn **researcher** with brief:
   - "For someone at [user-level] in [area], map the learning phases for [topic]: key concepts per phase, sequence dependencies, best current sources per phase, common mistakes"
7. Wait for researcher results

**Map design:**
8. Design learning phases ordered by concept dependency — not alphabetical or by course structure
9. For each phase: select 1-3 sources maximum (highest signal per hour — not a reading list)
10. Write checkpoints as specific, testable tasks — not passive comprehension checks
11. Flag common mistakes per phase from the researcher results

**Note generation:**
12. Draft the full learning map following the structure in `vault-templates/knowledge-note.md` (adapted for learning maps)

**Gate:**
13. Show the proposed map structure to the user (phases + goals, not full content)
14. Wait for confirmation or adjustments to phase scope or sequence

**Post-approval:**
15. Write to `20-knowledge/[area]/[topic]/[topic]-learning-map.md`
16. Link prerequisites and related notes

**`--update` mode:**
1. Read the existing learning map
2. Ask: "What phase are you on? What has worked, what hasn't?"
3. Update: mark completed phases, replace sources that were not useful, add notes from the user's experience

**`--audit` mode:**
1. Read the existing learning map
2. Check each resource: is the URL still valid? Is there a better source now?
3. Check the sequence: is this still the right order given what has changed in the field?
4. Report findings and proposed updates

---

## Output format

```
Learning map created: [topic]
Written to: 20-knowledge/[area]/[topic]/topic-learning-map.md

Phases: [N]
Estimated total time: [hours]

Prerequisites confirmed: [[prereq-1]], [[prereq-2]]
Prerequisites to fill first: [[missing]] — /learn [missing] or /research [missing]

Start with Phase 1: [phase-name]
→ [resource title] — [URL]
```

---

## Gate conditions

- **Soft gate at step 13**: show the phase structure before building the full map — sequence approval before content
- No gate on prerequisite check — always run it; user decides what to do with the results

---

## Error states

| Situation | Response |
| --------- | -------- |
| No topic provided | Ask "What do you want to learn?" |
| Topic too broad | "That's a very broad area. Would you like a map for [sub-topic-A] or [sub-topic-B] first?" |
| User has no relevant background in the prerequisites | Flag clearly and ask whether to start with prerequisites or proceed anyway |
| `--update` map not found | Report error, list existing learning maps in the vault |
| Researcher returns no high-quality current sources | Flag: "I found limited high-quality sources for this topic at [date]. Map confidence will be medium." |
