---
title: "postmortem command"
created: 2026-06-04
updated: 2026-06-04
status: active
type: agent
area: system
tags: [command, system, postmortem, retrospective, learning]
related: ["[[postmortem]]", "[[gap-detector]]", "[[connector]]"]
confidence: high
---

## Trigger

`/postmortem [project-name]`
`/postmortem --quick [project-name]`
`/postmortem --patterns`
`/postmortem --update [project-name]`

---

## Inputs

| Input | Required | Description |
| ----- | -------- | ----------- |
| `project-name` | Required (except `--patterns`) | Name of the project to postmortem |
| `--quick` | Flag | 3-question abbreviated version |
| `--patterns` | Flag | Cross-project pattern analysis — no project-name needed |
| `--update` | Flag | Mid-project retrospective for an active project |

If project-name not provided (and not `--patterns`): ask "Which project are we doing the postmortem for?"

---

## Steps

1. Read `vault-config.json` for the vault path
2. Read `00-me.md` for context

**Project note check:**
3. Look for `10-projects/[project-name].md`
4. If not found: inform the user — "No project note found for [name]. Let me run /audit first to create a baseline."
5. Run `/audit [project-name]` if confirmed, then return to postmortem
6. Read the project note — absorb all available context before the first question

**Interview (one question at a time):**

Full postmortem — 8 questions in order:
1. "What was the original goal, and what did you actually end up with?"
2. "What was the single best decision made on this project? Why was it right?"
3. "What was the single worst decision? What was the root cause — not just the symptom?"
4. "What did you not know at the start that you know now?"
5. "If you had to start this again from zero tomorrow, what would you change in the first week?"
6. "Was there a moment when the outcome became predictable? When, and what signal did you miss?"
7. "What patterns from this project have you seen in other projects you've worked on?"
8. "What is the one thing future-you should read or know before doing anything similar?"

Quick postmortem (`--quick`) — 3 questions only:
1. "What was the single best decision on this project? Why?"
2. "What was the single worst decision? Root cause?"
3. "What is the biggest thing you didn't know at the start that you know now?"

After each answer: acknowledge, extract the key insight, ask the next question. Do not rush.

**Synthesis:**
7. After all questions: synthesise answers into structured postmortem section
8. Scan other `10-projects/` notes — identify shared failure modes or wins
9. Draft postmortem section

**Gate:**
10. Show the drafted postmortem section to the user before writing
11. Wait for approval or changes

**Post-write:**
12. Append the postmortem section to `10-projects/[project-name].md`
13. Spawn **gap-detector** with the "what I didn't know" items — check for missing knowledge notes
14. Spawn **connector** to link the project note to related notes with similar patterns

**`--patterns` mode:**
1. Read all `10-projects/` notes containing a Postmortem section
2. Extract: worst decisions, root causes, knowledge gaps
3. Identify recurring patterns across projects
4. Report: "This root cause has appeared in [N] projects: [project-a], [project-b]..."
5. Suggest creating a knowledge note documenting the pattern if it appears 3+ times

---

## Output format

```
Postmortem complete: [[project-name]]

Postmortem section appended to: 10-projects/project-name.md

Knowledge gaps identified: [N]
→ /research [topic-1]
→ /research [topic-2]

Pattern matches with other projects:
• Similar failure mode as [[project-b]]: [description]
```

---

## Gate conditions

- Questions are asked **one at a time** — never list all questions at once
- **Soft gate before writing**: show the synthesised postmortem section and wait for confirmation
- `/postmortem --patterns` never writes anything — report only

---

## Error states

| Situation | Response |
| --------- | -------- |
| No project-name provided | Ask "Which project are we doing the postmortem for?" |
| Project note not found | Offer to run /audit first |
| Project is still active and not `--update` | Clarify: "This project is still marked active. Should I do a mid-project retrospective with /postmortem --update?" |
| User gives very short answers | Ask a follow-up to extract the root cause before moving to the next question |
